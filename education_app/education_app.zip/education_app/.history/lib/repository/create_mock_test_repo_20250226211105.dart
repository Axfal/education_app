
import 'package:education_app/resources/exports.dart';

import '../model/create_mock_test_model.dart';

class CreateMockTestRepo {
  final BaseApiServices _apiServices = NetworkApiServices();
  Future<CreateMockTestModel> createMockTest(Map<String, dynamic> data) async {
    try {
      final response =
      await _apiServices.getPostApiResponse(AppUrl.createMockTest, data);
      if (kDebugMode) {
        print("Raw API Response: $response");
      }

      return CreateMockTestModel.fromJson(response);
    } catch (error) {
      if (kDebugMode) {
        print("API Error: $error");
      }
      rethrow;
    }
  }
}
