import 'package:education_app/resources/exports.dart';
import '../../model/create_mock_test_model.dart';
import '../../repository/create_mock_test_repo.dart';

class CreateMockTestProvider with ChangeNotifier {
  CreateMockTestRepo createMockTestRepo = CreateMockTestRepo();

  List<Questions> _questionList = [];
  List<Questions> get questionList => _questionList;

  bool _loading = false;
  bool get loading => _loading;

  CreateMockTestModel? _createMockTestModel;
  CreateMockTestModel? get createMockTestModel => _createMockTestModel;

  // Add debug print statements to track the flow
  Future<void> getQuestions(
      BuildContext context, Map<String, dynamic> data) async {
    try {
      _loading = true;
      notifyListeners();

      print("📡 Fetching questions with data: $data");

      final response = await createMockTestRepo.createMockTest(data);
      print("✅ API Response received: $response");

      if (response.success == true && response.questions != null) {
        _createMockTestModel = response;
        _questionList = response.questions!;
        print("📝 Questions loaded: ${_questionList.length}");

        // Initialize arrays with correct length
        _isSubmitted = List<bool>.filled(_questionList.length, false);
        _selectedOptions = List<int?>.filled(_questionList.length, null);
        _showExplanation = List<bool>.filled(_questionList.length, false);

        _numberOfQuestions = _questionList.length;
      } else {
        print("❌ No questions in response or success is false");
        _questionList = [];
        _numberOfQuestions = 0;
      }
    } catch (error) {
      print("❌ Error fetching questions: $error");
      _questionList = [];
      _numberOfQuestions = 0;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  // ... rest of your existing provider code ...
}
